namespace ZVB4.Conf
{
    public enum EnumWhatYouObj
    {
        None = 0, // 无
        ZombiSoftBody = 1, // 血肉僵尸软
        ZombiHardBody = 2, // 血肉僵尸硬
        //
        PlansSoftBody = 5, // 血肉植物软
        PlansHardBody = 6, // 血肉植物硬

        //
        MuTong = 11, // 木桶
        TieTong = 12, // 铁桶
        HuaXiangSan = 21 // 花箱伞
    }
}
