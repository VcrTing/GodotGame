namespace ZVB4.Conf
{
    public enum EnumHurts
    {
        Pea = 1,
        Vip = 3,
        Cold = 11,

        IceFreeze = 90,

        Boom = 100,

        Bait = 200,
    }
}
