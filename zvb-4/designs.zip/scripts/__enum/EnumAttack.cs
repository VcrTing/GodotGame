namespace ZVB4.Conf
{
    public enum EnumAttack
    {
        Plans = 1,
        Zombie = 2,
        Bullet = 3
    }
}
