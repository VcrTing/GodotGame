namespace ZVB4.Conf
{
    public enum EnumObjType
    {
        System = 0,
        Plans = 1,
        Zombie = 2,
        Things = 3
    }
}
