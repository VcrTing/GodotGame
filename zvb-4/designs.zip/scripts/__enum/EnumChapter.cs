namespace ZVB4.Conf
{
    public enum EnumChapter
    {
        None = 0,
        One1 = 1001,
        One2 = 1002,
        One3 = 1003,
        One4 = 1004,
        One5 = 1005,

        Seven1 = 7001,
        One6 = 1006,
        One7 = 1007,
        One8 = 1008,
        One9 = 1009,
        One10 = 1010,
        One11 = 1011,
        One12 = 1012,
        One13 = 1013,

        Seven2 = 7002,

    }
}
