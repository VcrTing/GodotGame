namespace ZVB4.Interface
{
    public interface IReword
    {
        bool Init(string name, int number, int value);
    }
}
