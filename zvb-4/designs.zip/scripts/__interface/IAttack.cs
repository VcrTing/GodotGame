using ZVB4.Conf;

namespace ZVB4.Interface
{
    public interface IAttack
    {
        bool CanAttack();
        int GetDamage();
        int GetDamageExtra();
    }
}
