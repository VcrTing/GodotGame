namespace ZVB4.Interface
{
    public interface IWorking
    {
        void SetWorkingMode(bool working);
        bool IsWorking();
    }
}