namespace ZVB4.Interface
{
    public interface IWhenDie
    {
        void WorkingWhenDie(string n);
    }
}