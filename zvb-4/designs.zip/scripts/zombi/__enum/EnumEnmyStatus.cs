namespace ZVB4.Conf
{
    public enum EnumEnmyStatus
    {
        None = 0,
        Idle = 1,
        Move = 10,
        Attack = 12,
        Working = 13,

        Die = 99
    }
}
