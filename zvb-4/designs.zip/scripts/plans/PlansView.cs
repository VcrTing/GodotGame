using Godot;
using System;

public partial class PlansView : Node2D
{
}
