using Godot;
using System;

public partial class Envs : Node2D
{
}
