using Godot;
using System;

public partial class BulletSingle : Node2D
{
}
