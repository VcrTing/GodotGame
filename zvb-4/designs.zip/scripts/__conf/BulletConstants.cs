
using System.Collections.Generic;

namespace ZVB4.Conf
{
    public static class BulletConstants
    {
        public const string BulletPeaName = "BulletPea";
        public const string BulletPeaDoubleName = "BulletPeaDouble";
        public const string BulletPeaGoldName = "BulletPeaGold";
        public const string BulletLanMeiName = "BulletLanMei";
        public const string BulletYangTaoName = "BulletYangTao";
        public const string BulletXiguaBingName = "BulletXiguaBing";

        // 植物名，bullet
        public static readonly Dictionary<string, string> BulletDict = new Dictionary<string, string>
        {
            { PlansConstants.Pea, FolderConstants.WaveBullet + "bullet_zero.tscn" },
            { PlansConstants.PeaDouble, FolderConstants.WaveBullet + "bullet_zero_s.tscn" },
            { PlansConstants.LanMei, FolderConstants.WaveBullet + "bullet_lan_mei.tscn" },
            { PlansConstants.YangTao, FolderConstants.WaveBullet + "bullet_yang_tao.tscn" },
            //
            { PlansConstants.PeaGold, FolderConstants.WaveBullet + "diancang/bullet_pea_gold.tscn" },
            { PlansConstants.XiguaBing, FolderConstants.WaveBullet + "bullet_xigua_bing.tscn" },
        };
        

        public const float LiveTimeTotal = 8f;
        public const int Base = 10;
        public const int DamageBasic = Base * 50;
        public const int Zero = 0;

        public static readonly Dictionary<string, int> BulletDamageDict = new Dictionary<string, int>
        {
            { BulletPeaName, DamageBasic },
            { BulletPeaDoubleName, DamageBasic },
            { BulletLanMeiName, Base * 70 },
            { BulletYangTaoName, Base * 50 },
            { BulletPeaGoldName, Base * 200 },
            { BulletXiguaBingName, Base * 300 },
        };
        public static readonly Dictionary<string, int> BulletGroupDamageDict = new Dictionary<string, int>
        {
            // { BulletPeaName, Zero },
            { BulletLanMeiName, Base * 20 },
            // { BulletYangTaoName, Zero },
            { BulletXiguaBingName, Base * 100 },
        };

        public static readonly Dictionary<string, int> BulletExtraDamageDict = new Dictionary<string, int>
        {
            // { BulletPeaName, Zero },
            // { BulletLanMeiName, Zero },
            // { BulletYangTaoName, Zero },
            { BulletPeaDoubleName, DamageBasic },
            { BulletXiguaBingName, Base * 100 },
        };


        public static int GetDamage(string n)
        {
            if (BulletDamageDict.TryGetValue(n, out int dmg))
                return dmg;
            return 0;
        }
        public static int GetGroupDamage(string n)
        {
            if (BulletGroupDamageDict.TryGetValue(n, out int dmg))
                return dmg;
            return 0;
        }
        public static int GetDamageExtra(string n)
        {
            if (BulletExtraDamageDict.TryGetValue(n, out int dmg))
                return dmg;
            return 0;
        }

        // 子弹初始速度
        public const float SpeedBasic = 800f;

        public static float GetSpeed(string n)
        {
            return n switch
            {
                BulletPeaGoldName => 2200f,
                BulletPeaName => 800f,
                BulletPeaDoubleName => 920f,
                BulletLanMeiName => 600f,
                BulletYangTaoName => 1000f,
                BulletXiguaBingName => 1120f,
                _ => 700f,
            };
        }

        // 其他植物
        public const int DamageCherry = 1000 * 10;
        public const int DamageLaJiao = 1000 * 16;
        public static int GetPlansDamage(string plantName)
        {
            if (plantName == PlansConstants.Cherry) return DamageCherry;
            if (plantName == PlansConstants.LaJiao) return DamageLaJiao;
            return 0;
        }
        public static int GetPlansDamageExtra(string plantName)
        {
            if (plantName == PlansConstants.Cherry) return 10;
            if (plantName == PlansConstants.LaJiao) return 16;
            return 0;
        }

        
        // 根据key获取 Bullet 场景路径
        public static string GetBullet(string key)
        {
            if (BulletDict.TryGetValue(key, out var value))
                return value;
            return string.Empty;
        }
    }

}